from django.apps import AppConfig


class Trabajo17Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'trabajo17'
