from django.shortcuts import render
from django.http import HttpResponse
from django.template import Template, Context

from trabajo17 import models

def asignaturas(request):
    asignaturas = models.Asignatura.objects.all()
    return render(request, 'asignaturas.html', {'asignaturas': asignaturas})

def profesor(request):
    profesor = models.Profesores.objects.all()
    return render(request, 'profesores.html', {'profesores': profesor})

def estudiantes(request):
    estudiantes = models.Estudiantes.objects.all()
    return render(request, 'estudiantes.html', {'estudiantes': estudiantes})

def carreras(request):
    carreras = models.Carreras.objects.all()
    return render(request, 'carreras.html', {'carreras': carreras})
