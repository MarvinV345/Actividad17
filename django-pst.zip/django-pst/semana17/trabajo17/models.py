from django.db import models

class Carreras(models.Model):
    ID_Carrera = models.AutoField(primary_key=True)
    Nombre_Carrera = models.CharField(max_length=255)

class Estudiantes(models.Model):    
    ID_Estudiante = models.AutoField(primary_key=True)
    Nombre = models.CharField(max_length=255)
    Apellido = models.CharField(max_length=255)
    Edad = models.IntegerField()
    Carrera_ID = models.ForeignKey(Carreras, on_delete=models.CASCADE, db_column='ID_Carrera')

class Profesores(models.Model):
    ID_Profesor = models.AutoField(primary_key=True)
    Nombre = models.CharField(max_length=255)
    Apellido = models.CharField(max_length=255)
    Correo = models.CharField(max_length=255)
    
class Asignatura(models.Model):
    ID_Asignatura = models.AutoField(primary_key=True)
    Nombre_Asignatura = models.CharField(max_length=255)
    Profesor_ID = models.ForeignKey(Profesores, on_delete=models.CASCADE, db_column='ID_Profesor')
    Carrera_ID = models.ForeignKey(Carreras, on_delete=models.CASCADE, db_column='ID_Carrera')
